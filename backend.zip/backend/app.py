from flask import Flask, request, jsonify
from flask_cors import CORS
from typing import List, Dict, Any
from dataclasses import dataclass
from enum import Enum
import yfinance as yf
import requests
from datetime import datetime
import os
from dotenv import load_dotenv
import openai
import pandas as pd
import json
import pandas as pd
import logging
from datetime import datetime, date
import numpy as np
import pandas as pd
from decimal import Decimal
import json


# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()


class EnhancedJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime, date, pd.Timestamp)):
            return obj.isoformat()
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.int64, np.int32, np.int16, np.int8)):
            return int(obj)
        if isinstance(obj, (np.float64, np.float32, np.float16)):
            return float(obj)
        if pd.isna(obj):
            return None
        if isinstance(obj, Decimal):
            return str(obj)
        if isinstance(obj, pd.Series):
            return obj.to_list()
        if isinstance(obj, pd.DataFrame):
            return {
                "columns": obj.columns.tolist(),
                "data": obj.values.tolist(),
                "index": obj.index.tolist(),
            }
        return super().default(obj)


# Initialize Flask app
app = Flask(__name__)
CORS(
    app,
    resources={
        r"/*": {
            "origins": ["http://localhost:3000"],  # Add your frontend origin
            "methods": ["GET", "POST", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"],
            "expose_headers": ["Content-Range", "X-Content-Range"],
        }
    },
)


class DataCategory(Enum):
    PRICE = "price"
    NEWS = "news"
    FUNDAMENTALS = "fundamentals"
    TECHNICAL = "technical"
    SENTIMENT = "sentiment"
    FINANCIAL_STATEMENTS = "financial_statements"
    INSIDER_TRADING = "insider_trading"
    COMPANY_PROFILE = "company_profile"
    VISUALIZATION = "visualization"


@dataclass
class APIEndpoint:
    name: str
    category: DataCategory
    description: str
    endpoint: str


# Available API endpoints
AVAILABLE_ENDPOINTS = [
    APIEndpoint(
        name="av_company_overview",
        category=DataCategory.COMPANY_PROFILE,
        description="Get company overview including description, sector, industry",
        endpoint="OVERVIEW",
    ),
    APIEndpoint(
        name="av_news_sentiment",
        category=DataCategory.NEWS,
        description="Get latest news and sentiment analysis",
        endpoint="NEWS_SENTIMENT",
    ),
    APIEndpoint(
        name="av_income_statement",
        category=DataCategory.FINANCIAL_STATEMENTS,
        description="Get annual and quarterly income statements",
        endpoint="INCOME_STATEMENT",
    ),
    APIEndpoint(
        name="av_cash_flow",
        category=DataCategory.FINANCIAL_STATEMENTS,
        description="Get cash flow statements",
        endpoint="CASH_FLOW",
    ),
    APIEndpoint(
        name="yf_price",
        category=DataCategory.PRICE,
        description="Get real-time and historical price data",
        endpoint="history",
    ),
    APIEndpoint(
        name="yf_institutional_holders",
        category=DataCategory.FUNDAMENTALS,
        description="Get institutional holders information",
        endpoint="institutional_holders",
    ),
    APIEndpoint(
        name="yf_recommendations",
        category=DataCategory.SENTIMENT,
        description="Get analyst recommendations",
        endpoint="recommendations",
    ),
    APIEndpoint(
        name="yf_calendar",
        category=DataCategory.FUNDAMENTALS,
        description="Get earnings calendar and events",
        endpoint="calendar",
    ),
    APIEndpoint(
        name="fmp_insider_trading",
        category=DataCategory.INSIDER_TRADING,
        description="Get insider trading activities",
        endpoint="/api/v3/insider-trading",
    ),
    APIEndpoint(
        name="custom_stock_graph",
        category=DataCategory.VISUALIZATION,
        description="Generate stock price visualization data with technical indicators",
        endpoint="stock_graph",
    ),
]


class FinancialDataPipeline:
    def __init__(self):
        self.av_api_key = os.getenv("ALPHAVANTAGE_API_KEY")
        self.fmp_api_key = os.getenv("FMP_API_KEY")
        openai.api_key = os.getenv("OPENAI_API_KEY")

    def _detect_ticker(self, question: str) -> str:
        """Use GPT to detect the relevant stock ticker from the question."""
        logger.info("Detecting ticker from question...")

        prompt = f"""Extract the stock ticker symbol from this question. If multiple companies are mentioned, identify the main one being asked about. If no specific ticker is mentioned but a company name is, provide its ticker. Only return the ticker symbol in capital letters, nothing else.

Question: "{question}"
"""

        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=10,
            temperature=0,
        )

        ticker = response.choices[0].message.content.strip()
        logger.info(f"Detected ticker: {ticker}")

        # Verify ticker exists
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            if "regularMarketPrice" in info:
                return ticker
        except Exception as e:
            logger.error(f"Error verifying ticker {ticker}: {str(e)}")
            return None

        return ticker

    def _select_relevant_endpoints(self, question: str) -> List[APIEndpoint]:
        """Use GPT to determine which endpoints are most relevant for the question."""
        logger.info("Selecting relevant endpoints...")

        endpoints_description = "\n".join(
            [
                f"- {endpoint.name}: {endpoint.description} (Category: {endpoint.category.value})"
                for endpoint in AVAILABLE_ENDPOINTS
            ]
        )

        prompt = f"""Given the following financial data API endpoints:

{endpoints_description}

And this user question: "{question}"

Select between 3 most relevant API endpoints to answer this question effectively.
Return only the endpoint names in a comma-separated list, no explanation needed."""

        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=50,
            temperature=0,
        )

        selected_endpoints = response.choices[0].message.content.strip().split(",")
        selected_endpoints = [endpoint.strip() for endpoint in selected_endpoints]

        return [
            endpoint
            for endpoint in AVAILABLE_ENDPOINTS
            if endpoint.name in selected_endpoints
        ]

    def fetch_alpha_vantage_data(self, endpoint: APIEndpoint, ticker: str) -> Dict:
        """Fetch data from Alpha Vantage API."""
        logger.info(f"Fetching Alpha Vantage data for endpoint {endpoint.name}...")
        base_url = "https://www.alphavantage.co/query"

        params = {
            "function": endpoint.endpoint,
            "symbol": ticker,
            "apikey": self.av_api_key,
        }

        try:
            response = requests.get(base_url, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching Alpha Vantage data: {str(e)}")
            return None

    def get_problematic_types(data, path="", problems=None):
        """Recursively find all problematic data types that can't be serialized."""
        if problems is None:
            problems = []

        if isinstance(data, dict):
            for k, v in data.items():
                try:
                    json.dumps(v, cls=EnhancedJSONEncoder)
                except TypeError:
                    problems.append(
                        {
                            "path": f"{path}.{k}" if path else k,
                            "type": str(type(v)),
                            "value_preview": str(v)[:100] if v is not None else "None",
                        }
                    )
                get_problematic_types(v, f"{path}.{k}" if path else k, problems)
        elif isinstance(data, list):
            for i, v in enumerate(data):
                try:
                    json.dumps(v, cls=EnhancedJSONEncoder)
                except TypeError:
                    problems.append(
                        {
                            "path": f"{path}[{i}]",
                            "type": str(type(v)),
                            "value_preview": str(v)[:100] if v is not None else "None",
                        }
                    )
                get_problematic_types(v, f"{path}[{i}]", problems)

        return problems

    def fetch_yahoo_finance_data(self, endpoint: APIEndpoint, ticker: str) -> Any:
        logger.info(f"Fetching Yahoo Finance data for endpoint {endpoint.name}...")
        try:
            stock = yf.Ticker(ticker)
            method = getattr(stock, endpoint.endpoint)

            if callable(method):
                data = method()

                # Handle DataFrame conversion consistently
                if isinstance(data, pd.DataFrame):
                    # Convert DataFrame to records format
                    return data.reset_index().to_dict(orient="records")

                # Handle other data types
                return data

        except Exception as e:
            logger.error(f"Error fetching Yahoo Finance data: {str(e)}")
            logger.error(f"Error details:", exc_info=True)
            return None

    def fetch_fmp_data(self, endpoint: APIEndpoint, ticker: str) -> Dict:
        """Fetch data from Financial Modeling Prep API."""
        logger.info(
            f"Fetching Financial Modeling Prep data for endpoint {endpoint.name}..."
        )
        base_url = "https://financialmodelingprep.com"
        url = f"{base_url}{endpoint.endpoint}/{ticker}?apikey={self.fmp_api_key}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching FMP data: {str(e)}")
            return None

    def fetch_stock_graph_data(self, ticker: str, period: str = "1y") -> Dict:
        """Fetch and process data for stock visualization."""
        logger.info(f"Fetching stock graph data for {ticker}...")
        try:
            stock = yf.Ticker(ticker)
            hist = stock.history(period=period)

            if hist.empty:
                return None

            # Calculate technical indicators
            hist["SMA20"] = hist["Close"].rolling(window=20).mean()
            hist["SMA50"] = hist["Close"].rolling(window=50).mean()

            # RSI
            delta = hist["Close"].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            hist["RSI"] = 100 - (100 / (1 + rs))

            # MACD
            exp1 = hist["Close"].ewm(span=12, adjust=False).mean()
            exp2 = hist["Close"].ewm(span=26, adjust=False).mean()
            hist["MACD"] = exp1 - exp2
            hist["Signal_Line"] = hist["MACD"].ewm(span=9, adjust=False).mean()

            return {
                "dates": hist.index.strftime("%Y-%m-%d").tolist(),
                "price_data": {
                    "close": hist["Close"].round(2).tolist(),
                    "high": hist["High"].round(2).tolist(),
                    "low": hist["Low"].round(2).tolist(),
                    "volume": hist["Volume"].tolist(),
                },
                "technical_indicators": {
                    "sma20": hist["SMA20"].round(2).tolist(),
                    "sma50": hist["SMA50"].round(2).tolist(),
                    "rsi": hist["RSI"].round(2).tolist(),
                    "macd": hist["MACD"].round(2).tolist(),
                    "macd_signal": hist["Signal_Line"].round(2).tolist(),
                },
            }
        except Exception as e:
            logger.error(f"Error generating stock graph data: {str(e)}")
            return None

    def process_question(self, question: str) -> Dict[str, Any]:
        """Process a user question and return relevant financial data."""
        logger.info(f"Processing question: {question}")

        ticker = self._detect_ticker(question)
        if not ticker:
            raise ValueError("Could not detect a valid ticker from the question")

        selected_endpoints = self._select_relevant_endpoints(question)

        results = {
            "metadata": {
                "question": question,
                "detected_ticker": ticker,
                "timestamp": datetime.now().isoformat(),
            }
        }

        for endpoint in selected_endpoints[:4]:
            try:
                if endpoint.name == "custom_stock_graph":
                    data = self.fetch_stock_graph_data(ticker)
                elif endpoint.name.startswith("av_"):
                    data = self.fetch_alpha_vantage_data(endpoint, ticker)
                elif endpoint.name.startswith("yf_"):
                    data = self.fetch_yahoo_finance_data(endpoint, ticker)
                elif endpoint.name.startswith("fmp_"):
                    data = self.fetch_fmp_data(endpoint, ticker)

                if data is not None:
                    results[endpoint.name] = {
                        "data": data,
                        "category": endpoint.category.value,
                        "description": endpoint.description,
                    }

            except Exception as e:
                logger.error(
                    f"Error fetching data for endpoint {endpoint.name}: {str(e)}"
                )
                continue

        return results


# Initialize the pipeline
pipeline = FinancialDataPipeline()


# Flask routes
@app.route("/")
def home():
    return jsonify({"message": "Financial Data API is running"})


@app.route("/available-endpoints", methods=["GET"])
def get_available_endpoints():
    return jsonify(
        {
            "endpoints": [
                {
                    "name": endpoint.name,
                    "category": endpoint.category.value,
                    "description": endpoint.description,
                }
                for endpoint in AVAILABLE_ENDPOINTS
            ]
        }
    )


@app.route("/analyze", methods=["POST"])
def analyze_stock():
    try:
        data = request.get_json()
        if not data or "question" not in data:
            return jsonify({"error": "Missing 'question' in request body"}), 400

        results = pipeline.process_question(data["question"])
        return jsonify(results)
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/stock/<ticker>", methods=["GET"])
def get_stock_data(ticker):
    try:
        # Get requested endpoints from query parameters
        endpoints = (
            request.args.get("endpoints", "").split(",")
            if request.args.get("endpoints")
            else None
        )

        results = {}
        for endpoint in AVAILABLE_ENDPOINTS:
            if endpoints and endpoint.name not in endpoints:
                continue

            if endpoint.name.startswith("av_"):
                data = pipeline.fetch_alpha_vantage_data(endpoint, ticker)
            elif endpoint.name.startswith("yf_"):
                data = pipeline.fetch_yahoo_finance_data(endpoint, ticker)
            elif endpoint.name.startswith("fmp_"):
                data = pipeline.fetch_fmp_data(endpoint, ticker)
            elif endpoint.name == "custom_stock_graph":
                data = pipeline.fetch_stock_graph_data(ticker)

            if data is not None:
                results[endpoint.name] = {
                    "data": data,
                    "category": endpoint.category.value,
                    "description": endpoint.description,
                }

        return jsonify(results)
    except Exception as e:
        logger.error(f"Error fetching stock data: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/chat", methods=["POST", "OPTIONS"])
def chat():
    if request.method == "OPTIONS":
        response = jsonify({"status": "ok"})
        response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
        response.headers.add(
            "Access-Control-Allow-Headers", "Content-Type,Authorization"
        )
        response.headers.add("Access-Control-Allow-Methods", "POST,OPTIONS")
        return response

    try:
        data = request.get_json()
        question = data.get("message") or data.get("question")
        if not question:
            return (
                jsonify({"error": "Missing required 'message' or 'question' field"}),
                400,
            )

        logger.info("\n" + "=" * 50)
        logger.info(f"New Question: {question}")

        # Get ticker and endpoints
        ticker = pipeline._detect_ticker(question)
        selected_endpoints = pipeline._select_relevant_endpoints(question)

        logger.info(f"\nDetected ticker: {ticker}")
        logger.info(
            "Selected endpoints: " + ", ".join(ep.name for ep in selected_endpoints)
        )

        # Process question and get results
        results = pipeline.process_question(question)

        # Debug: Save the JSON response before sending
        try:
            # Convert to JSON string with pretty printing
            json_str = json.dumps(results, cls=EnhancedJSONEncoder, indent=2)

            # Create debug directory if it doesn't exist
            debug_dir = "debug_logs"
            if not os.path.exists(debug_dir):
                os.makedirs(debug_dir)

            # Save JSON file with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{debug_dir}/response_{timestamp}.json"

            with open(filename, "w") as f:
                f.write(json_str)

            logger.info(f"\nDebug: JSON response saved to {filename}")

            # Log the size of the response
            logger.info(f"Response size: {len(json_str)} bytes")

            # Log first level keys of the response
            logger.info(f"Response keys: {list(results.keys())}")

        except Exception as e:
            logger.error(f"Error saving debug JSON: {str(e)}")

        # Create and return the response
        try:
            response = jsonify(results)
            logger.info("\n✓ Final response serialization successful")
            return response
        except Exception as e:
            logger.error(f"\n✗ Final serialization failed: {str(e)}")
            return jsonify({"error": str(e)}), 500

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)
