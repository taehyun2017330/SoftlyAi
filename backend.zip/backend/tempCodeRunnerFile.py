def chat():
        if request.method == "OPTIONS":
            # Handle preflight request
            response = jsonify({"status": "ok"})
            response.headers.add("Access-Control-Allow-Origin", "http://localhost:3000")
            response.headers.add(
                "Access-Control-Allow-Headers", "Content-Type,Authorization"
            )
            response.headers.add("Access-Control-Allow-Methods", "POST,OPTIONS")
            return response

        # Handle actual request
        try:
            data = request.get_json()
            # Add your chat handling logic here
            return jsonify({"status": "success", "data": data})
        except Exception as e:
            logger.error(f"Error in chat endpoint: {str(e)}")
            return jsonify({"error": str(e)}), 500
