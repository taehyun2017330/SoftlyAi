import React from 'react';

const NewsCard = ({ news }) => (
  <div 
    className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
    onClick={() => window.open(news.url, '_blank')}
  >
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-600">{news.source}</span>
        <span className="text-sm text-gray-600">
          {new Date(news.time_published.replace(/(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})/, '$1-$2-$3T$4:$5:$6')).toLocaleString()}
        </span>
      </div>
      <h4 className="font-medium">{news.title}</h4>
      <p className="text-sm text-gray-700">{news.summary}</p>
      <div className="flex items-center gap-2">
        <span className={`text-sm font-medium ${
          news.overall_sentiment_label.toLowerCase().includes('bullish') 
            ? 'text-green-600' 
            : news.overall_sentiment_label.toLowerCase().includes('bearish')
            ? 'text-red-600'
            : 'text-gray-600'
        }`}>
          {news.overall_sentiment_label}
        </span>
      </div>
    </div>
  </div>
);

const NewsSentimentViz = ({ data }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Recent Market News</h3>
        {data.feed.slice(0, 5).map((news, index) => (
          <NewsCard key={index} news={news} />
        ))}
      </div>
    </div>
  );
};

export default NewsSentimentViz;