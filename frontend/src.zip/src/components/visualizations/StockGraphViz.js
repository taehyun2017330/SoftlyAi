import React, { useState } from 'react';
import {
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const StockGraphViz = ({ data }) => {
  const [timeframe, setTimeframe] = useState('3M');

  // Sanitize numerical values before processing
  const sanitizeValue = (value) => {
    if (typeof value === 'number' && !isNaN(value)) {
      return value;
    }
    return null;
  };
  
  // Process and combine all data with sanitization
  const processedData = data.dates.map((date, index) => ({
    date,
    price: sanitizeValue(data.price_data.close[index]),
    volume: sanitizeValue(data.price_data.volume[index]),
    sma20: sanitizeValue(data.technical_indicators.sma20[index]),
    sma50: sanitizeValue(data.technical_indicators.sma50[index]),
    rsi: sanitizeValue(data.technical_indicators.rsi[index]),
    macd: sanitizeValue(data.technical_indicators.macd[index]),
    macdSignal: sanitizeValue(data.technical_indicators.macd_signal[index]),
    macdHistogram: sanitizeValue(
      data.technical_indicators.macd[index] - data.technical_indicators.macd_signal[index]
    )
  }));

  // Filter data based on timeframe
  const getFilteredData = () => {
    const periods = {
      '3M': 63,
      '6M': 126,
      '1Y': 252
    };
    return processedData.slice(-periods[timeframe]);
  };

  const filteredData = getFilteredData();
  
  // Calculate current price and changes with null checks
  const currentPrice = filteredData[filteredData.length - 1]?.price ?? 0;
  const startPrice = filteredData[0]?.price ?? 0;
  const priceChange = currentPrice - startPrice;
  const priceChangePercent = startPrice ? ((priceChange / startPrice) * 100).toFixed(2) : '0.00';

  // Custom tooltip formatter to handle null values
  const formatTooltipValue = (value) => {
    if (value === null || value === undefined || isNaN(value)) {
      return 'N/A';
    }
    return typeof value === 'number' ? value.toFixed(2) : value;
  };


  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-2xl font-semibold">
            ${currentPrice.toFixed(2)}
            <span className={`ml-2 text-lg ${priceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {priceChange >= 0 ? '+' : ''}{priceChangePercent}%
            </span>
          </h3>
        </div>
        <div className="flex gap-2">
          {['3M', '6M', '1Y'].map(period => (
            <button
              key={period}
              onClick={() => setTimeframe(period)}
              className={`px-3 py-1 rounded ${
                timeframe === period 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {/* Price and Volume Chart */}
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date"
                angle={-45}
                textAnchor="end"
                height={60}
                interval={Math.floor(filteredData.length / 8)}
                fontSize={12}
              />
              <YAxis 
                yAxisId="price"
                domain={['auto', 'auto']}
                label={{ value: 'Price ($)', angle: -90, position: 'insideLeft' }}
              />
              <YAxis 
                yAxisId="volume"
                orientation="right"
                domain={['auto', 'auto']}
                label={{ value: 'Volume', angle: 90, position: 'insideRight' }}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-3 border rounded shadow-lg">
                        <p className="font-semibold">{label}</p>
                        <p className="text-blue-600">Price: ${payload[0]?.value?.toFixed(2)}</p>
                        <p className="text-gray-600">Volume: {payload[1]?.value?.toLocaleString()}</p>
                        <p className="text-green-600">SMA20: ${payload[2]?.value?.toFixed(2) || 'N/A'}</p>
                        <p className="text-purple-600">SMA50: ${payload[3]?.value?.toFixed(2) || 'N/A'}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend />
              <Bar 
                yAxisId="volume" 
                dataKey="volume" 
                fill="#64748b"
                opacity={0.3}
                name="Volume"
              />
              <Line
                yAxisId="price"
                type="monotone"
                dataKey="price"
                stroke="#2563eb"
                dot={false}
                name="Price"
              />
              <Line
                yAxisId="price"
                type="monotone"
                dataKey="sma20"
                stroke="#16a34a"
                dot={false}
                name="SMA20"
              />
              <Line
                yAxisId="price"
                type="monotone"
                dataKey="sma50"
                stroke="#9333ea"
                dot={false}
                name="SMA50"
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Technical Indicators */}
        <div className="grid grid-cols-2 gap-4">
          {/* RSI Chart */}
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={filteredData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date"
                  hide
                />
                <YAxis 
                  domain={[0, 100]}
                  label={{ value: 'RSI', angle: -90, position: 'insideLeft' }}
                />
                <Line
                  type="monotone"
                  dataKey="rsi"
                  stroke="#dc2626"
                  dot={false}
                />
                <CartesianGrid opacity={0.1} />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white p-2 border rounded shadow-lg">
                          <p className="font-semibold">{label}</p>
                          <p className="text-red-600">RSI: {payload[0]?.value?.toFixed(2)}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* MACD Chart */}
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={filteredData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date"
                  hide
                />
                <YAxis 
                  label={{ value: 'MACD', angle: -90, position: 'insideLeft' }}
                />
                <Bar
                  dataKey="macdHistogram"
                  fill={(d) => d.macdHistogram >= 0 ? '#16a34a' : '#dc2626'}
                  name="MACD Histogram"
                />
                <Line
                  type="monotone"
                  dataKey="macd"
                  stroke="#2563eb"
                  dot={false}
                  name="MACD"
                />
                <Line
                  type="monotone"
                  dataKey="macdSignal"
                  stroke="#ea580c"
                  dot={false}
                  name="Signal"
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white p-2 border rounded shadow-lg">
                          <p className="font-semibold">{label}</p>
                          <p className="text-blue-600">MACD: {payload[1]?.value?.toFixed(2)}</p>
                          <p className="text-orange-600">Signal: {payload[2]?.value?.toFixed(2)}</p>
                          <p className={payload[0]?.value >= 0 ? 'text-green-600' : 'text-red-600'}>
                            Histogram: {payload[0]?.value?.toFixed(2)}
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StockGraphViz;