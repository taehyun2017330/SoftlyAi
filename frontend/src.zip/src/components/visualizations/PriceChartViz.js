import React from 'react';
import { 
  ComposedChart, 
  Line, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from 'recharts';

const PriceChartViz = ({ data, ticker }) => {
  const processedData = data.map(item => ({
    date: new Date(item.Date).toLocaleDateString(),
    high: item.High,
    low: item.Low,
    open: item.Open,
    close: item.Close,
    volume: item.Volume,
    candleColor: item.Close >= item.Open ? '#16a34a' : '#dc2626'
  }));

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <h3 className="text-lg font-semibold mb-4">{ticker} Price Chart</h3>
      <div className="h-[400px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={processedData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="date" 
              angle={-45}
              textAnchor="end"
              height={60}
              interval={2}
              fontSize={12}
            />
            <YAxis 
              yAxisId="price"
              domain={['auto', 'auto']}
              label={{ value: 'Price ($)', angle: -90, position: 'insideLeft' }}
            />
            <YAxis 
              yAxisId="volume"
              orientation="right"
              label={{ value: 'Volume', angle: 90, position: 'insideRight' }}
            />
            <Tooltip
              content={({ active, payload, label }) => {
                if (active && payload && payload.length) {
                  return (
                    <div className="bg-white p-4 border rounded shadow-lg">
                      <p className="font-semibold">{label}</p>
                      <p className="text-gray-600">Open: ${payload[0]?.payload.open?.toFixed(2)}</p>
                      <p className="text-gray-600">Close: ${payload[0]?.payload.close?.toFixed(2)}</p>
                      <p className="text-gray-600">High: ${payload[0]?.payload.high?.toFixed(2)}</p>
                      <p className="text-gray-600">Low: ${payload[0]?.payload.low?.toFixed(2)}</p>
                      <p className="text-gray-600">Volume: {payload[0]?.payload.volume?.toLocaleString()}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Legend />
            <Bar
              yAxisId="volume"
              dataKey="volume"
              fill="#6b7280"
              opacity={0.3}
              name="Volume"
            />
            <Line
              yAxisId="price"
              type="monotone"
              dataKey="close"
              stroke="#2563eb"
              dot={false}
              name="Close Price"
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
        {[
          {
            label: "Current Price",
            value: `$${processedData[processedData.length - 1].close.toFixed(2)}`,
            change: ((processedData[processedData.length - 1].close - processedData[0].close) / processedData[0].close * 100).toFixed(2),
          },
          {
            label: "Volume",
            value: processedData[processedData.length - 1].volume.toLocaleString(),
          },
          {
            label: "Day Range",
            value: `$${processedData[processedData.length - 1].low.toFixed(2)} - $${processedData[processedData.length - 1].high.toFixed(2)}`,
          },
          {
            label: "Period High",
            value: `$${Math.max(...processedData.map(d => d.high)).toFixed(2)}`,
          }
        ].map((stat, index) => (
          <div key={index} className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">{stat.label}</p>
            <p className="text-lg font-semibold">{stat.value}</p>
            {stat.change && (
              <p className={`text-sm ${parseFloat(stat.change) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {stat.change}%
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PriceChartViz;