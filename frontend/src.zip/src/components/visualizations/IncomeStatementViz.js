// src/components/visualizations/IncomeStatementViz.js
import React from 'react';
import { 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from 'recharts';

const IncomeStatementViz = ({ data, ticker }) => {
  // Process annual reports data
  const annualData = data.annualReports
    .slice(0, 5)
    .reverse()
    .map(report => ({
      year: report.fiscalDateEnding.split('-')[0],
      revenue: parseFloat((report.totalRevenue / 1e9).toFixed(2)),
      netIncome: parseFloat((report.netIncome / 1e9).toFixed(2)),
      operatingIncome: parseFloat((report.operatingIncome / 1e9).toFixed(2)),
      grossProfit: parseFloat((report.grossProfit / 1e9).toFixed(2)),
      researchDevelopment: parseFloat((report.researchAndDevelopment / 1e9).toFixed(2)),
      grossMargin: parseFloat(((report.grossProfit / report.totalRevenue) * 100).toFixed(2)),
      netMargin: parseFloat(((report.netIncome / report.totalRevenue) * 100).toFixed(2)),
    }));

  // Calculate YoY growth
  const latestYear = data.annualReports[0];
  const prevYear = data.annualReports[1];
  const yoyGrowth = {
    revenue: ((latestYear.totalRevenue - prevYear.totalRevenue) / prevYear.totalRevenue * 100).toFixed(2),
    netIncome: ((latestYear.netIncome - prevYear.netIncome) / prevYear.netIncome * 100).toFixed(2),
    operatingIncome: ((latestYear.operatingIncome - prevYear.operatingIncome) / prevYear.operatingIncome * 100).toFixed(2)
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 space-y-6">
      <h3 className="text-lg font-semibold">{ticker} Financial Metrics</h3>
      
      {/* Key Metrics Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            label: "Revenue",
            value: `$${(latestYear.totalRevenue / 1e9).toFixed(2)}B`,
            growth: yoyGrowth.revenue
          },
          {
            label: "Net Income",
            value: `$${(latestYear.netIncome / 1e9).toFixed(2)}B`,
            growth: yoyGrowth.netIncome
          },
          {
            label: "Operating Income",
            value: `$${(latestYear.operatingIncome / 1e9).toFixed(2)}B`,
            growth: yoyGrowth.operatingIncome
          },
          {
            label: "Gross Margin",
            value: `${((latestYear.grossProfit / latestYear.totalRevenue) * 100).toFixed(2)}%`
          }
        ].map((metric, index) => (
          <div key={index} className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">{metric.label}</p>
            <p className="text-lg font-semibold">{metric.value}</p>
            {metric.growth && (
              <p className={`text-sm ${parseFloat(metric.growth) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {metric.growth}% YoY
              </p>
            )}
          </div>
        ))}
      </div>

      {/* Revenue and Income Trends */}
      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={annualData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis />
            <Tooltip
              formatter={(value, name) => [`$${value}B`, name]}
              labelFormatter={(label) => `Year: ${label}`}
            />
            <Legend />
            <Line type="monotone" dataKey="revenue" name="Revenue" stroke="#2563eb" strokeWidth={2} />
            <Line type="monotone" dataKey="netIncome" name="Net Income" stroke="#16a34a" strokeWidth={2} />
            <Line type="monotone" dataKey="operatingIncome" name="Operating Income" stroke="#9333ea" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Margin Analysis */}
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={annualData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis unit="%" />
            <Tooltip
              formatter={(value) => [`${value}%`]}
              labelFormatter={(label) => `Year: ${label}`}
            />
            <Legend />
            <Line type="monotone" dataKey="grossMargin" name="Gross Margin" stroke="#dc2626" strokeWidth={2} />
            <Line type="monotone" dataKey="netMargin" name="Net Margin" stroke="#ea580c" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default IncomeStatementViz;