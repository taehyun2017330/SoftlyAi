import React, { useState } from 'react';
import IncomeStatementViz from './visualizations/IncomeStatementViz';
import PriceChartViz from './visualizations/PriceChartViz';
import NewsSentimentViz from './visualizations/NewsSentimentViz';
import StockGraphViz from './visualizations/StockGraphViz';

const DataDisplayManager = ({ data }) => {
  const [showDebug, setShowDebug] = useState(false);

  const renderDataComponent = () => {
    try {
      const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
      
      // Get all available data keys
      const availableDataKeys = Object.keys(parsedData);
      const implementedKeys = ['av_income_statement', 'yf_price', 'av_news_sentiment','custom_stock_graph'];
      const unimplementedKeys = availableDataKeys.filter(key => 
        !implementedKeys.includes(key) && key !== 'metadata'
      );

      return (
        <div className="space-y-6">
          {/* Debug Toggle Button */}
          {unimplementedKeys.length > 0 && (
            <div className="flex justify-end">
              <button
                onClick={() => setShowDebug(!showDebug)}
                className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
              >
                {showDebug ? 'Hide' : 'Show'} Raw Data
              </button>
            </div>
          )}

          {/* Implemented Visualizations */}
          {parsedData.av_income_statement && (
            <IncomeStatementViz 
              data={parsedData.av_income_statement.data}
              ticker={parsedData.metadata?.detected_ticker}
            />
          )}

          {parsedData.yf_price && (
            <PriceChartViz 
              data={parsedData.yf_price.data}
              ticker={parsedData.metadata?.detected_ticker}
            />
          )}

          {parsedData.av_news_sentiment && (
            <NewsSentimentViz 
              data={parsedData.av_news_sentiment.data}
            />
          )}
          
          {parsedData.custom_stock_graph && (
            <StockGraphViz 
              data={parsedData.custom_stock_graph.data}
            />
          )}

          {/* Debug View for Unimplemented Data Types */}
          {unimplementedKeys.length > 0 && showDebug && (
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="text-lg font-semibold mb-4">Unimplemented Data Types</h3>
              {unimplementedKeys.map(key => (
                <div key={key} className="mb-6">
                  <h4 className="text-md font-medium text-gray-700 mb-2">{key}</h4>
                  <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto whitespace-pre-wrap">
                    {JSON.stringify(parsedData[key], null, 2)}
                  </pre>
                </div>
              ))}
            </div>
          )}

          {/* Empty State */}
          {!parsedData.av_income_statement && 
           !parsedData.yf_price && 
           !parsedData.av_news_sentiment && (
            <div className="bg-white rounded-lg shadow-sm p-4">
              <h3 className="text-lg font-semibold mb-4">Raw Data</h3>
              <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(parsedData, null, 2)}
              </pre>
            </div>
          )}
        </div>
      );
    } catch (error) {
      return (
        <div className="bg-white rounded-lg shadow-sm p-4">
          <div className="text-red-600 mb-4">
            <h3 className="font-semibold">Error Processing Data</h3>
            <p>There was an error processing the response. If this persists, please contact support.</p>
          </div>
          <div className="mt-4">
            <h4 className="font-medium mb-2">Raw Data:</h4>
            <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto whitespace-pre-wrap">
              {typeof data === 'string' ? data : JSON.stringify(data, null, 2)}
            </pre>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="w-full">
      {renderDataComponent()}
    </div>
  );
};

export default DataDisplayManager;