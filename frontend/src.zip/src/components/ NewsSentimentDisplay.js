import React from 'react';
import { Calendar, Clock, User, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const NewsSentimentDisplay = ({ data }) => {
  if (!data?.feed) {
    return <div className="text-gray-500">No news data available</div>;
  }

  const getSentimentColor = (label) => {
    switch (label) {
      case 'Bullish':
        return 'bg-green-100 text-green-800';
      case 'Somewhat-Bullish':
        return 'bg-emerald-50 text-emerald-700';
      case 'Bearish':
        return 'bg-red-100 text-red-800';
      case 'Somewhat-Bearish':
        return 'bg-rose-50 text-rose-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp.replace('T', ' '));
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="space-y-6">
      {data.feed.map((item, index) => (
        <Card key={index} className="overflow-hidden">
          <CardContent className="p-6">
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <Badge variant="secondary" className={getSentimentColor(item.overall_sentiment_label)}>
                {item.overall_sentiment_label}
              </Badge>
              
              <div className="flex items-center text-gray-500 text-sm">
                <Clock className="w-4 h-4 mr-1" />
                {formatDate(item.time_published)}
              </div>

              {item.source && (
                <Badge variant="outline" className="text-gray-600">
                  {item.source}
                </Badge>
              )}
            </div>

            <h3 className="text-lg font-semibold mb-3">
              {item.title}
            </h3>

            <p className="text-gray-600 mb-4 line-clamp-3">
              {item.summary}
            </p>

            <div className="flex flex-wrap gap-4">
              {item.authors?.length > 0 && (
                <div className="flex items-center text-sm text-gray-500">
                  <User className="w-4 h-4 mr-1" />
                  {item.authors.join(', ')}
                </div>
              )}

              {item.url && (
                <a 
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                >
                  <ExternalLink className="w-4 h-4 mr-1" />
                  Read more
                </a>
              )}
            </div>

            {item.ticker_sentiment?.length > 0 && (
              <div className="mt-4 border-t pt-4">
                <div className="flex flex-wrap gap-2">
                  {item.ticker_sentiment.map((ticker, idx) => (
                    <div key={idx} className="flex items-center">
                      <Badge 
                        variant="outline" 
                        className={`${
                          ticker.ticker_sentiment_score > 0.15 ? 'border-green-200 bg-green-50 text-green-700' :
                          ticker.ticker_sentiment_score < -0.15 ? 'border-red-200 bg-red-50 text-red-700' :
                          'border-gray-200 bg-gray-50 text-gray-700'
                        }`}
                      >
                        {ticker.ticker}
                        <span className="ml-1 opacity-75">
                          {(ticker.ticker_sentiment_score * 100).toFixed(1)}%
                        </span>
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default NewsSentimentDisplay;